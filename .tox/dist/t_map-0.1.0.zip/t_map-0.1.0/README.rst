=====
t-map
=====


.. image:: https://img.shields.io/pypi/v/t_map.svg
        :target: https://pypi.python.org/pypi/t_map

.. image:: https://img.shields.io/travis/merterden98/tmap.svg
        :target: https://travis-ci.com/merterden98/tmap

.. image:: https://readthedocs.org/projects/t-map/badge/?version=latest
        :target: https://t-map.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/merterden98/t_map/shield.svg
     :target: https://pyup.io/repos/github/merterden98/t_map/
     :alt: Updates





* Free software: MIT license
* Documentation: https://t-map.readthedocs.io.


