=====
Usage
=====

To use t-map in a project::

    import t_map
