"""Top-level package for t-map."""

__author__ = """Mert Erden"""
__email__ = 'mert.erden@tufts.edu'
__version__ = '0.1.0'
